package com.crudBasico.crudBasico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudBasicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
