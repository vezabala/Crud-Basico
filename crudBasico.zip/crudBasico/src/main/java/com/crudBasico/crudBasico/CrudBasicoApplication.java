package com.crudBasico.crudBasico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudBasicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudBasicoApplication.class, args);
	}

}
